window.designerConfig = {
	componentVersion: "latest",
	init: function(Expo) {
	  
	},
	events: [
		{
			name: "ctaLogo",
			type: "click",
			callback: function(Expo, event) {
				Expo.designerAPI.firePixel("ctaLogo", [{"eventName":"clickLive"}]);
				Expo.designerAPI.openUrl("https://www.lg.com/in","ctaLogo");
				Expo.designerAPI.pause();
			}
		},
		{
			name: "ctaLearnMore",
			type: "click",
			callback: function(Expo, event) {
				Expo.designerAPI.firePixel("ctaLearnMore", [{"eventName":"clickLive"}]);
				Expo.designerAPI.openUrl("https://www.lg.com/in","ctaLearnMore");
				Expo.designerAPI.pause();
			}
		}
	],
	callbacks: {
		mainUnitCloseCallback: function(callback, defaultVideoId) {
			this.designerAPI.switchPlayerInTab(defaultVideoId);
			arrowPlaylist.resetCarousel();
			callback(); 
		},

		videoEndedEvent: function(videoId, eventObj) {
			if (videoId == "video") {
			} else if (videoId == "video2") {
			} else if (videoId == "video3") {
			}
		},
	},		   
	components: [
		{
			name: "arrowPlaylist",
			props: {
				totalVideo: 1,
				autoPlay: true,
				arrowOpacity: 0.3,
				hideArrowTime: 3000
			},
			events: {
				videoCarouselEndEvent: function(Expo) {
					Expo.designerAPI.pause();
					Expo.designerAPI.showReplayIcon(true);
				},
				videoCarouselNext: function(Expo) {
				},
				videoCarouselPrev: function(Expo) {
				}
			}
		}

	]
}